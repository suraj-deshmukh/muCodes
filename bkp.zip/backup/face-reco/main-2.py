import os, uuid
from datetime import datetime
from deepface import DeepFace
from deepface.basemodels import Facenet
import pandas as pd

model = Facenet.loadModel()
dataset = '/media/suraj/HDD/dataset_image/face'

files = os.listdir(dataset)
features = []

start = datetime.now()
for index, i in enumerate(files):
    img_path = os.path.join(dataset, i)
    embedding = DeepFace.represent(img_path = img_path, model_name = 'Facenet', model=model, detector_backend='retinaface')
    doc = {"facial-features": embedding, "image_path": img_path}
    features.append(doc)

print(f"time to extract: {(datetime.now()-start).total_seconds()}")
df = pd.DataFrame(features)
df.to_csv('./feature.csv',index=False)