import os, json
from datetime import datetime
import pandas as pd
from elasticsearch import Elasticsearch
from elasticsearch.helpers import bulk
from deepface import DeepFace
from deepface.basemodels import Facenet

#es = Elasticsearch([{'host': 'localhost', 'port': '9200'}])
es = Elasticsearch(["https://elastic:tsqyFVpnwQ_kzzcXZlkb@18.203.159.253:9200"],ca_certs="/home/suraj/Documents/es-cluster-setup/http_ca.crt",ssl_assert_hostname=False)
print(es.ping())
model = Facenet.loadModel()
index_name = "image-embeddings-target"

mapping = {
    "mappings": {
        "properties": {
            "facial-features": {
                "type": "dense_vector",
                "dims": 128
            },
            "image_path": {"type": "text"}
        }
    },
    'settings': {"index.refresh_interval": "-1", "index.number_of_replicas": "0"}
}

es.indices.create(index=index_name, body=mapping)

df = pd.read_csv("feature.csv")
df['facial-features'] = df['facial-features'].apply(lambda x: json.loads(x))
df['_index'] = index_name
df = df.to_dict('records')
for i in range(10):
    bulk(client=es,actions=df)
