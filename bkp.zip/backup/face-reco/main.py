import os, uuid
from datetime import datetime
from elasticsearch import Elasticsearch
from elasticsearch.helpers import bulk
from deepface import DeepFace
from deepface.basemodels import Facenet

#es = Elasticsearch([{'host': 'localhost', 'port': '9200'}])
es = Elasticsearch(["https://elastic:tsqyFVpnwQ_kzzcXZlkb@18.203.159.253:9200"],ca_certs="/home/suraj/Documents/es-cluster-setup/http_ca.crt",ssl_assert_hostname=False)
model = Facenet.loadModel()
dataset = '/media/suraj/HDD/dataset_image/face'
batch = 100

mapping = {
    "mappings": {
        "properties": {
            "facial-features": {
                "type": "dense_vector",
                "dims": 128
            },
            "image_path": {"type": "text"}
        }
    },
    'settings': {'index': {'number_of_shards': 2}}
}

es.indices.create(index="image-embeddings-target", body=mapping)

files = os.listdir(dataset)



index = 0
for i in range(0, len(files), batch):
    features = []
    start = datetime.now()
    for img in files[i:i+batch]:
        img_path = os.path.join(dataset, img)
        embedding = DeepFace.represent(img_path = img_path, model_name = 'Facenet', model=model, detector_backend='retinaface')
        doc = {"facial-features": embedding, "image_path": img_path, '_index': "image-embeddings-target"}
        features.append(doc)
    bulk(client=es,actions=features*2)
    print("time to extract features: ", (datetime.now() - start).seconds, i)
    # break