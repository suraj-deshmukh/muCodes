import os
from datetime import datetime
from elasticsearch import Elasticsearch
from deepface import DeepFace
from deepface.basemodels import Facenet

img_path = '/media/suraj/HDD/dataset_image/00665.png'
model = Facenet.loadModel()
es = Elasticsearch([{'host': 'localhost', 'port': '9200'}])

start = datetime.now()
target_embedding = DeepFace.represent(img_path = img_path, model_name = 'Facenet', model=model, detector_backend='retinaface')
end = datetime.now()

query = {
    "size": 2,
    "query": {
    "script_score": {
        "query": {
            "match_all": {}
        },
        "script": {
            "source": "cosineSimilarity(params.queryVector, 'facial-features')",
            #"source": "1 / (1 + l2norm(params.queryVector, 'facial-features'))", #euclidean distance
            "params": {
                "queryVector": list(embedding)
            }
        }
    }
}}
res = es.search(index="image-embeddings-bkp", body=query)
print(f'time to fetch result: {(datetime.now()-start).seconds}')
print([i['_source']['image_path'] for i in res['hits']['hits']])