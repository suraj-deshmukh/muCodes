from celery_app import app
from tasks.tasks import get_embeddings
from celery.result import AsyncResult
app.control.purge()
import os

pngs = [os.path.join('/media/suraj/HDD/dataset_image/test', i) for i in os.listdir('/media/suraj/HDD/dataset_image/test')]
ids = []

for index, i in enumerate(pngs[0:10]):
    res = get_embeddings.delay(i, index)
    print(res.status)  # 'SUCCESS'
    print(res.id)  # '432890aa-4f02-437d-aaca-1999b70efe8d'
    ids.append(res.id)

print(ids)

for i in ids:
    res = AsyncResult(i,app=app)
    print(res.status) # 'SUCCESS'
    if res.status == 'SUCCESS':
        print(res.get()) # 7