from deepface import DeepFace
from deepface.basemodels import Facenet
from celery_app import app
from datetime import datetime

model = Facenet.loadModel()
print(f"model loaded successfully")

@app.task(track_started=True)
def get_embeddings(image_path, index):
    start = datetime.now()
    target_embedding = DeepFace.represent(img_path=image_path, model_name='Facenet', model=model, detector_backend='retinaface')
    print(f"total time: {(datetime.now()-start).total_seconds()}/{index}")
    return str(target_embedding), index

# celery -A celery_app worker -l debug -c 1 --pool threads