from celery.result import AsyncResult
from celery_app import app

ids = ['8f41fca4-a597-46cb-b64f-db5539fbcfaf', 'f03b3a2c-498f-4bdc-a033-152eeb071e22', 'bd9079a3-bfc8-41fb-8697-5ecf1194ea3e', '57b6ca1c-fa3d-4e45-bdb7-936a33bcb8f1', '52b0b6b2-71c5-43a8-abe1-2d0af84d8a60']

for i in ids:
    res = AsyncResult(i,app=app)
    print(res.status) # 'SUCCESS'
    if res.status == 'SUCCESS':
        print(res.get()) # 7
