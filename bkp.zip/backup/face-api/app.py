import os, uuid
from datetime import datetime
from fastapi import FastAPI, UploadFile, Response
from config import *
from utilities import *

app = FastAPI()


@app.post("/search")
def search(file: UploadFile, response: Response):
    try:
        start = datetime.now()
        filename = file.filename
        if filename.endswith(".png") or filename.endswith(".jpg") or filename.endswith(".jpeg"):
            filepath = os.path.join(input_file_path, str(uuid.uuid4())+'.'+filename.split('.')[-1])
            with open(filepath, "wb+") as f:
                f.write(file.file.read())
            result = get_result(filepath)
            return {"message": result, "duration": (datetime.now()-start).total_seconds()}
        else:
            response.status_code = 400
            return {"message": "please upload image file having png/jpg/jpeg extension"}
    except Exception as e:
        response.status_code = 500
        return {"message": str(e)}

@app.post("/index")
def search(file: UploadFile, response: Response):
    try:
        start = datetime.now()
        filename = file.filename
        if filename.endswith(".png") or filename.endswith(".jpg") or filename.endswith(".jpeg"):
            filepath = os.path.join(input_file_path, filename)
            with open(filepath, "wb+") as f:
                f.write(file.file.read())
            embedding = get_embeddings(filepath)
            doc = {"facial-features": embedding, "image_path": filepath, '_index': "image-embeddings-bkp"}
            bulk(client=es, actions=[doc])
            return {"message": "success"}
        else:
            response.status_code = 400
            return {"message": "please upload image file having png/jpg/jpeg extension"}
    except Exception as e:
        response.status_code = 500
        return {"message": str(e)}