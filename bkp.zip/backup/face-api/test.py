import os
import grequests
from datetime import datetime

def exception_handler(request, exception):
    print(exception)
    print("Request failed")


pngs = [os.path.join('/media/suraj/HDD/dataset_image/test', i) for i in os.listdir('/media/suraj/HDD/dataset_image/test')]


reqs = [grequests.post('http://localhost:8000/search', files={'file': open(i, "rb")}) for i in pngs*2]
print(len(reqs))
start = datetime.now()
resp = grequests.map(reqs, exception_handler=exception_handler)
end = datetime.now()
print(f"total time seconds: {(end-start).total_seconds()}")
print([i.json()['duration'] for i in resp])