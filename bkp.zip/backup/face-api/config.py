index_name = 'image-embeddings'
input_file_path = './uploaded_files'