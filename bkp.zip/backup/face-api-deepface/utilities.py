from elasticsearch import Elasticsearch
from elasticsearch.helpers import bulk
from deepface import DeepFace
from deepface.basemodels import Facenet
from config import *
from datetime import datetime

model = Facenet.loadModel()
print(f"model loaded successfully")
es = Elasticsearch([{'host': 'localhost', 'port': '9200'}])
# es = Elasticsearch(["https://elastic:d1VFu-L3zYt6csMbveVY@34.244.168.99:9200"],ca_certs="/home/suraj/Documents/es-cluster-setup/http_ca.crt",ssl_assert_hostname=False)
#for ec2 copy http_ca.crt to specific location and change owner to current user using "sudo chown ubuntu:ubuntu http_ca.crt" here ubuntu is user.
#es = Elasticsearch(["https://elastic:tsqyFVpnwQ_kzzcXZlkb@localhost:9200"], ca_certs="./http_ca.crt", ssl_assert_hostname=False) verify_certs=False

def get_embeddings(image_path):
    target_embedding = DeepFace.represent(img_path=image_path, model_name='Facenet', model=model, detector_backend='retinaface')
    return target_embedding


def get_search_result(target_embedding, top=7, threshold=.5):
    start = datetime.now()
    query = {
        "size": top,
        # "min_score": threshold,
        "query": {
            "script_score": {
                "query": {
                    "match_all": {}
                },
                "script": {
                    #"source": "cosineSimilarity(params.queryVector, 'facial-features')",
                    "source": "1 / (1 + l2norm(params.queryVector, 'facial-features'))", #euclidean distance
                    "params": {
                        "queryVector": list(target_embedding)
                    }
                }
            }
        }}
    res = es.search(index=index_name, body=query)
    print(f"total_query time: {(datetime.now()-start).total_seconds()}")
    print(res)
    return [{"score": i['_score'], "image_path": i['_source']['image_path']} for i in res['hits']['hits']] if res['hits']['hits'] else []


def get_result(image_path):
    embedding = get_embeddings(image_path)
    result = get_search_result(embedding)
    return result

# def add_image(image_path):
#     embedding = get_embeddings(image_path)
