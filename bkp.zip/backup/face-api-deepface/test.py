import os
import grequests


def exception_handler(request, exception):
    print(exception)
    print("Request failed")


pngs = [os.path.join('/media/suraj/HDD/dataset_image/test', i) for i in os.listdir('/media/suraj/HDD/dataset_image/test')]


reqs = [grequests.post('http://localhost:8000/search', files={'file': open(i, "rb")}) for i in pngs[0:1]]
print(len(reqs))

resp = grequests.map(reqs, exception_handler=exception_handler)
print([i.json()['duration'] for i in resp])